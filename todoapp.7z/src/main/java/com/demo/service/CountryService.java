package com.demo.service;

import com.demo.model.Country;

import java.util.List;

public interface CountryService {

    List<Country> listAll();

}
